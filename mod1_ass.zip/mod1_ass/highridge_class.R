# Load necessary libraries
library(R6)
library(logging)


HighridgeProcessor <- R6Class("HighridgeProcessor",
                              public = list(
                                log_path = NULL,
                                logger = NULL,
                                
                                initialize = function(log_path) {
                                  self$log_path <- log_path
                                  self$logger <- self$initialize_logger()
                                },
                                
                                initialize_logger = function() {
                                  # Configure the logger to log to the file
                                  basicConfig(level = "INFO")
                                  addHandler(writeToFile, file = self$log_path)
                                  loginfo("Logger initialized")
                                  return(getLogger())
                                },
                                
                                employee_generator = function() {
                                  workers_list <- list()
                                  for (i in 1:400) {
                                    worker <- list(
                                      name = paste("Highridge_emp", i, sep = "_"),
                                      gender = sample(c("Male", "Female"), 1),
                                      salary = sample(5000:36000, 1),
                                      dept = sample(c("Finance", "Technology", "Operations", "Risk", "HR"), 1)
                                    )
                                    workers_list[[i]] <- worker
                                  }
                                  return(workers_list)
                                },
                                
                                generate_payment_slip = function(worker) {
                                  tryCatch({
                                    name <- worker$name
                                    gender <- worker$gender
                                    salary <- worker$salary
                                    dept <- worker$dept
                                    
                                    # Conditional statements for Employee Levels
                                    employee_level <- "Not Classified"
                                    if (salary > 10000 & salary < 20000) {
                                      employee_level <- "A1"
                                    } else if (salary > 7500 & salary < 30000 & gender == "Female") {
                                      employee_level <- "A5-F"
                                    }
                                    
                                    # Print payment slip
                                    cat("Payment Slip for", name, ":\n")
                                    cat("Gender:", gender, "\n")
                                    cat("Department:", dept, "\n")
                                    cat("Salary: $", salary, "\n")
                                    cat("Employee Level:", employee_level, "\n")
                                    cat(rep("-", 45), "\n")
                                  }, error = function(e) {
                                    logerror(paste("Error generating slip for", worker$name, ":", e$message), logger = self$logger)
                                  })
                                }
                              )
)
