from highridge_class import HighridgeProcessor
import time
import os 

#log_path = "C:/Users/sodiq.otunba/Desktop/Interswitch code/NXU/MSDA/BAN6420/Module 1/paymentslip.log"
log_directory = os.path.join(os.path.dirname(__file__), 'logs')  # Assuming the logs are in a 'logs' folder
log_path = os.path.join(log_directory, 'paymentslip.log')

# Check if the log file exists, raise an error if it doesn't
if not os.path.exists(log_path):
    raise FileNotFoundError("Log file 'paymentslip.log' not found in the 'logs' directory")

worker_generator = HighridgeProcessor(log_path)
worker_generator.initialize_logger()
workers = worker_generator.employee_generator()

worker_generator.logger.info("Generating workers payslip")
for worker in workers:
    worker_generator.logger.info(f"Generating payslip for {worker['name']}, kindly wait a few seconds")
    print(f"Generating payslip for {worker['name']}, kindly wait a few seconds\n")
    time.sleep(1)
    worker_generator.generate_payment_slip(worker)
