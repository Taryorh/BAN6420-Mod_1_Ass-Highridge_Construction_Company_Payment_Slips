# Define log directory and log path
source("C:/Users/sodiq.otunba/Desktop/Interswitch code/NXU/MSDA/BAN6420/Module 1/highridge_class.R")
log_directory <- "logs"
log_path <- file.path(log_directory, "paymentslip.log")

# Check if the logs directory exists, if not, create it
if (!dir.exists(log_directory)) {
  dir.create(log_directory)
}

# Check if log file exists, if not, create an empty log file
if (!file.exists(log_path)) {
  file.create(log_path)
}

processor <- HighridgeProcessor$new(log_path = log_path)

# Initialize the logger
processor$initialize_logger()

# Generate the workers list
workers <- processor$employee_generator()

# Log and generate payment slips
loginfo("Generating workers' payslips", logger = processor$logger)
for (worker in workers) {
  loginfo(paste("Generating payslip for", worker$name, "- kindly wait a few seconds"), logger = processor$logger)
  cat("Generating payslip for", worker$name, "- kindly wait a few seconds\n\n")
  Sys.sleep(1)  # Simulating delay
  processor$generate_payment_slip(worker)
}

