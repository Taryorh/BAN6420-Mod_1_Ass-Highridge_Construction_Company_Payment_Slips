import logging
import random

class HighridgeProcessor:
    def __init__(self, log_path):
        self.log_path = log_path
        self.logger = self.initialize_logger()
        
        
    def initialize_logger(self):
        log_format = "%(asctime)s %(levelname)s %(message)s"
        logging.basicConfig(filename=self.log_path, format=log_format, filemode='a')
        logger = logging.getLogger()

        logger.setLevel(logging.INFO)
        return logger
        
        
    def employee_generator(log_path):
        workers_list = []
        for i in range(1, 401):
            worker = {
                "name": f"Highridge_emp_{i}",
                "gender": random.choice(["Male", "Female"]),
                "salary": random.randint(5_000, 36_000),
                "dept": random.choice(["Finance", "Technology","Operations","Risk","HR"]),
            }
            workers_list.append(worker)
        return workers_list
    
    
    def generate_payment_slip(self,worker):
        try:
            name = worker['name']
            gender = worker['gender']
            salary = worker['salary']
            dept = worker['dept']
            
            # Conditional Statements for Employee Levels
            if 10_000 < salary < 20_000:
                employee_level = "A1"
            elif 7500 < salary < 30000 and gender == "Female":
                employee_level = "A5-F"
            else:
                employee_level = "Not Classified"
            
            # Print payment slip
            print(f"Payment Slip for {name}:")
            print(f"Gender: {gender}")
            print(f"Department: {dept}")
            print(f"Salary: ${salary}")
            print(f"Employee Level: {employee_level}")
            print("-" * 45)

        except KeyError as e:
            self.logger.error(f"Missing key: {e}")
            print(f"Missing key: {e}")
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            print(f"An error occurred: {e}")

    
    
